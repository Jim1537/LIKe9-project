#if (ARDUINO >=100)
	#include "Arduino.h"
#else
	#include "WProgram.h"
#endif
#include "jTRes.h"

void median_swap (float *xp, float *yp) {
  int temp = *xp;
  *xp = *yp;
  *yp = temp;
}
float median (float arr[], byte n) {
  byte i, j;
  for (i = 0; i <= n - 1; i++)
    for (j = 0; j <= n - i - 1; j++)
      if (arr[j] > arr[j + 1])
        median_swap(&arr[j], &arr[j + 1]);
  return arr[round(n / 2) - 1];
}

jTRes::jTRes(byte pin) {
  pinMode(pin, INPUT);
  _pin = pin;
}


void jTRes::set(float VCC) {
	_VCC = VCC;
}
void jTRes::set(float VCC, int R) {
	_VCC = VCC;
	_R = R;
}
void jTRes::set(float VCC, int R, int RT0, int BC, float T0) {
	_VCC = VCC;
	_R = R;
	_RT0 = RT0;
	_BC = BC;
	_T0 = T0 + 273.15;
}


void jTRes::update() {
	float VRT = (_VCC / 1023.00) * analogRead(_pin);
	_tprK = (1 / ((log((VRT / ((_VCC - VRT) / _R)) / _RT0) / _BC) + (1 / _T0)));
	if (++_counter >= _marrSize - 1) _counter = 0;
	_marr[_counter] = _tprK;
	_tprKf = median(_marr, _marrSize);
}


float jTRes::readK(bool filtered) {
	if (filtered) {
		return round(_tprKf*100)/100;
	} else {
		return round(_tprK*100)/100;
	}
}
float jTRes::readC(bool filtered) {
	if (filtered) {
		return round((_tprKf - 273.15)*100)/100 ;
	} else {
		return round((_tprK - 273.15)*100)/100 ;
	}
}
float jTRes::readF(bool filtered) {
	if (filtered) {
		return round(((_tprKf - 273.15) * 1.8 + 32)*100)/100;
	} else {
		return round(((_tprK - 273.15) * 1.8 + 32)*100)/100;
	}
}