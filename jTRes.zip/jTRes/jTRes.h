/*
 jTRes is a simple library, intended for getting readings from one or several thermistors.
 See using instructions in the example program.
 
 created Jun 2020
 by Vladimir Gorshunin aka Jim (http://jimblog.me)
 */

#ifndef jTRes_h
	#define jTRes_h
	#if (ARDUINO >=100)
		#include "Arduino.h"
	#else
		#include "WProgram.h"
	#endif

	class jTRes  {
		public:
			jTRes(byte pin);							// Class declaration (control pin number)
		
			void set(float VCC);							// Set operating voltage (see description below)
			void set(float VCC, int R);					// Set operating voltage and Pull-down resistor value (see description below)
			void set(float VCC, int R, int RT0, int BC, float T0);	// Set operating voltage, Pull-down resistor value and RT0/K/T0 from thermistor datasheet  (see description below)
		
			void update();								// Update sensor readings
		
			float readK(bool filtered = false);				// Get reading, converted to Kelvin (true = instant raw, false = filtered by median)
			float readC(bool filtered = false);				// Get reading, converted to Celsius (true = instant raw, false = filtered by median)
			float readF(bool filtered = false);				// Get reading, converted to Fahrenheit (true = instant raw, false = filtered by median)
		
		private:
			byte _pin;
			float _VCC = 3.3;							// Thermistor control voltage (default = 3.3V)
			int _R = 10000;							// Pull-down resistor Ω (default = 10000 = 10KΩ)
			int _RT0 = 10000;							// Resistance Ω from thermistor parameters (default = 10000 = 10KΩ)
			int _BC = 3977;							// Beta coefficient from thermistor parameters (default = 3977)
			float _T0 = 298.15;							// T0 from thermistor parameters, converted to Kelvin (25 + 273.15)
		
			float _tprK;
			float _tprKf;
			byte _marrSize = 7;
			float _marr[7];
			byte _counter = 0;
	};
#endif
